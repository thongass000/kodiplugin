from urllib.parse import urlencode, parse_qsl
import sys, xbmcgui, xbmcplugin, requests, os, re
import xbmcaddon, xbmc, urllib.request
import shutil, zipfile
addon = xbmcaddon.Addon()
info_update = "https://www.dropbox.com/scl/fi/ii5dcdnn2x3i9kk4stgg6/ver.txt?rlkey=s2f5u1b1x6ozom342fpmjh6hj&st=iuwgjw3r&dl=1"
download_url = "https://www.dropbox.com/scl/fi/clzeq4gef77sfknuwn2uw/plugin.video.90phuttv.zip?rlkey=conqnudz4btkrq6svkas0zkc5&st=hiido3ka&dl=1"
current_version = addon.getAddonInfo('version')
response = requests.get(info_update, timeout=15)
if response.status_code == 200:
	latest_version = response.content.decode('ISO-8859-1')
	if latest_version != current_version:
		temp_dir = os.path.join(addon.getAddonInfo('path'), 'temp')
		os.makedirs(temp_dir, exist_ok=True)
		response = requests.get(download_url)
		if response.status_code == 200:
			zip_file = os.path.join(temp_dir, 'update.zip')
			with open(zip_file, 'wb') as f:
				f.write(response.content)
			with zipfile.ZipFile(zip_file, 'r') as zip_ref:
				zip_ref.extractall(temp_dir)
			extracted_dir = os.path.join(temp_dir, addon.getAddonInfo('id'))
			addon_dir = addon.getAddonInfo('path')
			src_files = os.listdir(extracted_dir)
			for file_name in src_files:
				full_file_name = os.path.join(extracted_dir, file_name)
				shutil.move(full_file_name, addon_dir + file_name)
			shutil.rmtree(temp_dir)
			dialog = xbmcgui.Dialog()
			dialog.ok('Đã cập nhật phiên bản mới!!!', 'Vui lòng khởi động lại Kodi để cập nhật có hiệu lực.')
			
base_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON_PATH = addon.getAddonInfo('path')
ICONS_DIR = os.path.join(ADDON_PATH, 'media', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'media', 'fanart')
def get_url(**kwargs):
	return base_url + '?' + urlencode(kwargs)
menu = [{
	"name": "Highlights",
	"id": "highlights",
	"logo": os.path.join(ICONS_DIR, 'highlights.jpg'),
	"fanart": os.path.join(FANART_DIR, 'highlights.jpg'),
	"desc": "Highlights c\u00e1c tr\u1eadn \u0111\u1ea5u t\u00e2m \u0111i\u1ec3m",
},
{
	"name": "90PhutTV",
	"id": "90phut",
	"logo": os.path.join(ICONS_DIR, '90phut.png'),
	"fanart": os.path.join(FANART_DIR, '90phut.jpg'),
	"desc": "Tr\u1ef1c ti\u1ebfp b\u00f3ng \u0111\u00e1 90PhutTV",
},
{
	"name": "ThapcamTV",
	"id": "thapcam",
	"logo": os.path.join(ICONS_DIR, 'thapcam.png'),
	"fanart": os.path.join(FANART_DIR, 'thapcam.png'),
	"desc": "Tr\u1ef1c ti\u1ebfp ThapcamTV",
}]

def list_menu(menu):
	for k in menu:
		name = k["name"]
		match = k["id"]
		logo = k["logo"]
		fanart = k["fanart"]
		desc = k["desc"]
		list_item = xbmcgui.ListItem(name)
		list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
		list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
		list_item.setProperty("IsPlayable", 'false')
		url = get_url(action='list_type', link=match)
		xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
	xbmcplugin.endOfDirectory(HANDLE)

def list_90phut():
	headers = {
			  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
			  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			  'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
			  'Connection': 'keep-alive'
			  }
	from datetime import datetime
	api = 'https://api.vebo.xyz/api/match/featured/mt/'
	data_match = requests.get(url=api, headers=headers).json()
	logo_default = os.path.join(ICONS_DIR, '90phut.png')
	for item in data_match['data']:
		logo = item['tournament']['logo']
		if not logo:
			logo = logo_default
		timestampp = str(item['timestamp']).replace('0000', '0')
		time = datetime.fromtimestamp(int(timestampp)).strftime('%Hh%M-%d/%m')
		blv = '|BLV: ' + item['commentators'][0]['name'] if item['commentators'] and item['commentators'][0]['name'] else ''
		name = f"{time}: {item['name']}{blv}"
		match = item['id']
		fanart = ""
		desc = item['tournament']['name']
		list_item = xbmcgui.ListItem(name)
		list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
		list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
		list_item.setProperty("IsPlayable", 'false')
		url = get_url(action='90phut', link=match)
		xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
	xbmcplugin.endOfDirectory(HANDLE)

def list_thapcam():
	headers = {
			  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
			  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			  'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
			  'Connection': 'keep-alive'
			  }
	from datetime import datetime
	api = 'https://api.thapcam.xyz/api/match/featured/mt/'
	data_match = requests.get(url=api, headers=headers).json()
	logo_default = os.path.join(ICONS_DIR, 'thapcam.png')
	for item in data_match['data']:
		logo = item['tournament']['logo']
		if not logo:
			logo = logo_default
		timestampp = str(item['timestamp']).replace('0000', '0')
		time = datetime.fromtimestamp(int(timestampp)).strftime('%Hh%M-%d/%m')
		blv = '|BLV: ' + item['commentators'][0]['name'] if item['commentators'] and item['commentators'][0]['name'] else ''
		name = f"{time}: {item['name']}{blv}"
		match = item['id']
		fanart = ""
		desc = item['tournament']['name']
		list_item = xbmcgui.ListItem(name)
		list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
		list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
		list_item.setProperty("IsPlayable", 'false')
		url = get_url(action='thapcam', link=match)
		xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
	xbmcplugin.endOfDirectory(HANDLE)

def list_link_90phut(link):
	headers = {
			  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
			  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			  'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
			  'Connection': 'keep-alive'
			  }
	api = 'https://api.vebo.xyz/api/match/'+link+'/meta'
	data_match = requests.get(url=api, headers=headers).json()
	if not data_match['data']['play_urls'][0]['url']:
		logo = os.path.join(ICONS_DIR, '90phut.png')
		name = 'Trận đấu chưa diễn ra'
		match = 'http://127.0.0.1'
		fanart = ""
		desc = "Chưa có link hoặc trận đấu chưa diễn ra!"
		list_item = xbmcgui.ListItem(name)
		list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
		list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
		list_item.setProperty("IsPlayable", 'true')
		xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
	else:
		for item in data_match['data']['play_urls']:
			if "SD/playlist" not in item['url']:
				logo = os.path.join(ICONS_DIR, '90phut.png')
				name = item['name']
				match = item['url']+'|Referer=https://i.fdcdn.xyz/'
				fanart = ""
				desc = "Link: "+item['name']
				list_item = xbmcgui.ListItem(name)
				list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
				list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
				list_item.setProperty("IsPlayable", 'true')
				xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
	xbmcplugin.endOfDirectory(HANDLE)

def list_link_thapcam(link):
	headers = {
			  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
			  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			  'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
			  'Connection': 'keep-alive'
			  }
	api = 'https://api.thapcam.xyz/api/match/'+link+'/meta'
	data_match = requests.get(url=api, headers=headers).json()
	if not data_match['data']['play_urls'][0]['url']:
		logo = os.path.join(ICONS_DIR, 'thapcam.png')
		name = 'Trận đấu chưa diễn ra'
		match = 'http://127.0.0.1'
		fanart = ""
		desc = "Chưa có link hoặc trận đấu chưa diễn ra!"
		list_item = xbmcgui.ListItem(name)
		list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
		list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
		list_item.setProperty("IsPlayable", 'true')
		xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
	else:
		for item in data_match['data']['play_urls']:
			if "SD/playlist" not in item['url']:
				logo = os.path.join(ICONS_DIR, 'thapcam.png')
				name = item['name']
				match = item['url']+'|Referer=https://i.fdcdn.xyz/'
				fanart = ""
				desc = "Link: "+item['name']
				list_item = xbmcgui.ListItem(name)
				list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
				list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
				list_item.setProperty("IsPlayable", 'true')
				xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
	xbmcplugin.endOfDirectory(HANDLE)

def list_highlights():
	headers = {
			  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
			  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			  'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
			  'Connection': 'keep-alive'
			  }
	api = 'https://api.vebo.xyz/api/news/vebotv/list/xemlai/'
	data_match = requests.get(url=api, headers=headers).json()
	for item in data_match['data']['list']:
		logo = item['feature_image']
		name = item['name']
		match = item['id']
		fanart = ""
		desc = item['name']
		list_item = xbmcgui.ListItem(name)
		list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
		list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
		list_item.setProperty("IsPlayable", 'true')
		url = get_url(action='highlights', link=match)
		xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
	xbmcplugin.endOfDirectory(HANDLE)

def play_highlights(link):
	headers = {
			  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
			  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			  'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
			  'Connection': 'keep-alive'
			  }
	api = 'https://api.vebo.xyz/api/news/vebotv/detail/'+link
	data_match = requests.get(url=api, headers=headers).json()
	match = data_match['data']['video_url']
	list_item = xbmcgui.ListItem('PlayTream', path=match)
	xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

def router(string):
	params = dict(parse_qsl(string))
	if not params:
		list_menu(menu)
	elif params['action'] == 'list_type':
		if params['link'] == '90phut':
			list_90phut()
		elif params['link'] == 'thapcam':
			list_thapcam()
		elif params['link'] == 'highlights':
			list_highlights()
	elif params['action'] == '90phut':
		list_link_90phut(params['link'])
	elif params['action'] == 'thapcam':
		list_link_thapcam(params['link'])
	elif params['action'] == 'highlights':
		play_highlights(params['link'])

	else:
		raise ValueError(f'Invalid paramstring: {string}!')

if __name__ == '__main__':
	router(sys.argv[2][1:])